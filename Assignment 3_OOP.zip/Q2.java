import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner inp=new Scanner(System.in);
        ArrayList<Integer> list = new ArrayList<Integer>();

        System.out.print("Enter a sequence of numbers ending wih 0: ");
        Integer n=inp.nextInt();
        while (n.intValue() != 0) {
            list.add(n);
            n=inp.nextInt();
        }
        System.out.println("The largest number in the input="+max(list));
    }


    public static Integer max(ArrayList<Integer> list) {
        if (list.size()==0)
            return null;

        Integer max=ist.get(0);
        for (int i=0;i<list.size();i++) {
            if (list.get(i)>max)
                max=list.get(i);
        }
        return max;
    }
}
